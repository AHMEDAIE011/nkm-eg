<?php

return [
    'permessions'=>[
        'posts'           =>' Managment Posts',
        'categories'      =>' Managment Categories',
        'settings'        =>' Managment Settings',
        'users'           =>' Managment Users',
        'admins'          =>' Managment Admins',
        'contacts'        =>' Managment Contacts',
        'home'            =>' Managment Home Page',
        'authorizations'  =>' Managment Authorizations',
        'profile'         => 'Managment Porile',
        'notifications'   => 'Managment Notifications',
    ],
];
