<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'home'   => 'home',
    'products' => 'products',
    'ContactUs'=> 'ContactUs',
    'about'=> 'about',
    'account'=> 'account',
    'allCategory'=> 'All Category',
    'about text 1'=> 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam nesciunt id eos ab, accusantium odit sit totam exercitationem voluptatem laudantium blanditiis eveniet. Saepe quod illum dolores nulla eveniet harum beatae.',
    'about text 2'=> 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam nesciunt id eos ab, accusantium odit sit totam exercitationem voluptatem laudantium blanditiis eveniet. Saepe quod illum dolores nulla eveniet harum beatae.',
    'showMore'=> 'Show More',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
    ''=> '',
];
