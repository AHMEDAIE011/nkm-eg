<?php $__env->startSection('title'); ?>
    contacts
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Contact Table</h1>
   

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Contact managment</h6>
        </div>

        <?php echo $__env->make('admin.contacts.filter.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>title</th>
                            <th>Status</th>
                            <th>phone</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>title</th>
                            <th>Status</th>
                            <th>phone</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->email); ?></td>
                        <td><?php echo e($contact->title); ?></td>
                        <td><?php echo e($contact->status==0? 'unread': 'read'); ?></td>
                        <td><?php echo e($contact->phone); ?></td>
                        <td><?php echo e($contact->created_at->diffForHumans()); ?></td>
                        <td>
                            <a href="javascript:void(0)" onclick="if(confirm('Do you want to delete the contact')){document.getElementById('delete_contact_<?php echo e($contact->id); ?>').submit()} return false"><i class="fa fa-trash"></i></a>
                            <a href="<?php echo e(route('admin.contacts.show' , $contact->id)); ?>" ><i class="fa fa-eye"></i></a>
                        </td>
                     </tr>

                     <form id="delete_contact_<?php echo e($contact->id); ?>" action="<?php echo e(route('admin.contacts.destroy' , $contact->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                     </form>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <tr>
                            <tdv class="alert alert-info" colspan="6"> No contacts</td>
                         </tr>
                     <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($contacts->appends(request()->input())->links()); ?>

            </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>