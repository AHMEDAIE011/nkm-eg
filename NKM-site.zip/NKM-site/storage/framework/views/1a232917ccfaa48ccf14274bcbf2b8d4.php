<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_desc'); ?>
    <?php echo e($getSetting->small_desc); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('header'); ?>
<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<?php
    $latest_three_posts = $posts->where('header_pro', 1)->take(3);

?>
    <!-- Top News Start-->
    <div class="top-news">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 tn-left">
                    <div class="row tn-slider">
                       <?php $__currentLoopData = $latest_three_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-md-6">
                        <div class="tn-img tn-img-slid">
                            <img  src="<?php echo e(asset($post->images->first()->path)); ?>" />
                            <div class="tn-title">
                                <?php if(App::getLocale() == 'ar'): ?>
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                <?php else: ?>
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-6 tn-right">
                    <?php
                        $four_posts = $posts->where('header_pro', 1)->take(4);
                    ?>
                    <div class="row">
                        <?php $__currentLoopData = $four_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="tn-img tn-img-4">
                                <img style="" src="<?php echo e(asset($post->images->first()->path)); ?>" />
                                <div class="tn-title">
                                    <?php if(App::getLocale() == 'ar'): ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top News End-->

  <!-- start About -->
<div class="about" id="about">
    <div class="container">
      <h2 class="special-heading">About</h2>
      <p>Less is more work</p>
      <div class="about-content">
        <div class="image">
            <img src="<?php echo e(asset('assets/frontend/img/18.jpeg')); ?>" alt="">
        </div>
        <div class="text">
          <p><?php echo e(__('home.about text 1')); ?></p>
          <hr>
          <p><?php echo e(__('home.about text 2')); ?></p> 
        </div>
      </div>
    </div>
  </div>
  <!-- End About -->

    <!-- Category News Start-->
    <div class="cat-news">
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $categories_with_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <?php if(App::getLocale() == 'ar'): ?>
                    <h2><?php echo e($category->name_ar); ?></h2>

                    <?php else: ?>
                    
                    <h2><?php echo e($category->name); ?></h2>
                    <?php endif; ?>
                    <div class="row cn-slider">
                       <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="cn-img">
                                <img style="height: 440px;width:445px" src="<?php echo e(asset($post->images->first()->path) ?? ''); ?>" />
                                <div class="cn-title">
                                    <?php if(App::getLocale() == 'ar'): ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    <?php endif; ?>                                </div>
                            </div>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Category News End-->



    <!-- Tab News Start (finished)-->
    <div class="tab-news">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <ul class="nav nav-pills nav-justified">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#featured"> Popular Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#popular"> Oldest Products</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="featured" class="container tab-pane active">
                           <?php $__currentLoopData = $gretest_posts_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tn-news">
                                <div class="tn-img">
                                    <img  src="<?php echo e(asset( asset($post->images->first()->path) )); ?>" />
                                </div>
                                <div class="tn-title">
                                    <?php if(App::getLocale() == 'ar'): ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?> التعليقات(<?php echo e($post->comments_count); ?>)</a>

                                    <?php else: ?>
                                    
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?> comment(<?php echo e($post->comments_count); ?>)</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div id="popular" class="container tab-pane fade">
                            <?php $__currentLoopData = $oldest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tn-news">
                                <div class="tn-img">
                                    <img src="<?php echo e(asset($post->images->first()->path) ?? ''); ?>" />
                                </div>
                                <div class="tn-title">
                                    <?php if(App::getLocale() == 'ar'): ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    <?php endif; ?>                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>

                <div class="col-md-6">
                    <ul class="nav nav-pills nav-justified">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#m-viewed">Latest Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#m-read">Most Products</a>
                        </li>

                    </ul>

                    <div class="tab-content">
                        
                        <div id="m-viewed" class="container tab-pane active">
                           <?php $__currentLoopData = $latest_three_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="tn-news">
                            <div class="tn-img">
                                <img src="<?php echo e(asset($post->images->first()->path) ?? ''); ?>" />
                            </div>
                            <div class="tn-title">
                                <?php if(App::getLocale() == 'ar'): ?>
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                <?php else: ?>
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                <?php endif; ?>                            </div>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div id="m-read" class="container tab-pane fade">
                          <?php $__currentLoopData = $gretest_posts_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="tn-news">
                            <div class="tn-img">
                                <img src="<?php echo e(asset($post->images->first()->path) ?? ''); ?>" />
                            </div>
                            <div class="tn-title">
                                <?php if(App::getLocale() == 'ar'): ?>
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?> (<?php echo e($post->num_of_views); ?>)</a>
                                <?php else: ?>
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?> (<?php echo e($post->num_of_views); ?>)</a>
                                <?php endif; ?>
                            </div>
                        </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Tab News Start-->

    <!-- Main News Start-->
    <div class="main-news">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-9">
                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 d-flex justify-content-center">
                                <div class="mn-img">
                                  <img style="height: 295px;width:460px" src="<?php echo e(asset($post->images->first()->path) ?? ''); ?>" />
                                    <div class="mn-title">
                                        <?php if(App::getLocale() == 'ar'): ?>
                                        <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                        <?php endif; ?>                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($posts->links()); ?>

                    </div>
                </div>

                <div class="col-lg-3">
                    <div class="mn-list">
                        <h2>Read More</h2>
                        <ul>
                          <?php $__currentLoopData = $read_more_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if(App::getLocale() == 'ar'): ?>
                          <li><a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a></li>
                          <?php else: ?>
                          <li><a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a></li>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main News End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/frontend/index.blade.php ENDPATH**/ ?>