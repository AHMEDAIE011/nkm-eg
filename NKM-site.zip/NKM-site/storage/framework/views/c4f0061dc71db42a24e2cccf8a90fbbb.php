<div class="row">

    <!-- Content Column -->
    <div class="col-lg-6 mb-4">

        <!-- Project Card Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Last Posts</h6>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Comments</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>

                      <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts')): ?>
                              <a href="<?php echo e(route('admin.posts.show' , $post->id)); ?>">
                                <?php echo e(Illuminate\Support\Str::limit($post->title , 20)); ?>

                              </a>
                              <?php endif; ?>
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('posts')): ?>
                                <?php echo e(Illuminate\Support\Str::limit($post->title , 20)); ?>

                              <?php endif; ?>
                            </td>
                            <td><?php echo e($post->category->name); ?></td>
                            <td><?php echo e($post->comments_count); ?></td>
                            <td><?php echo e($post->status == 0 ?'Not Active':'Active'); ?></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

        </div>


    </div>

     <!-- Content Column -->
     <div class="col-lg-6 mb-4">

        <!-- Project Card Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Last Comments</h6>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Post</th>
                            <th>Comment</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                     <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $latest_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($comment->user->name); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts')): ?>
                            <a href="<?php echo e(route('admin.posts.show' , $comment->post->id)); ?>">
                                <?php echo e(Illuminate\Support\Str::limit($comment->post->title , 20)); ?>

                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('posts')): ?>
                                <?php echo e(Illuminate\Support\Str::limit($comment->post->title , 20)); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e(Illuminate\Support\Str::limit($comment->comment , 40)); ?></td>
                        <td><?php echo e($comment->status == 0 ?'Not Active':'Active'); ?></td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                     <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

        </div>


    </div>


</div>
<?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/livewire/admin/latest-posts-comments.blade.php ENDPATH**/ ?>