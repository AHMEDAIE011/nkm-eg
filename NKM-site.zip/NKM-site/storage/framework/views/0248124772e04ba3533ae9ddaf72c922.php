<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title> <?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />

    <meta
      content="Bootstrap News Template - Free HTML Templates"
      name="keywords"
    />

    <meta content="<?php echo $__env->yieldContent('meta_desc'); ?>" name="description" />
    <meta name="robots" content="index, follow">
    <!-- Favicon -->
    <link href="<?php echo e(asset('assets/frontend/img/favicon.ico')); ?>" rel="icon" />

    <!-- Google Fonts -->
    <link
      href="https://fonts.googleapis.com/css?family=Montserrat:400,600&display=swap"
      rel="stylesheet"
    />

    <!-- CSS Libraries -->
    <link
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
      rel="stylesheet"
    />

    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />
    <link href="<?php echo e(asset('assets/frontend')); ?>/lib/slick/slick.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/frontend')); ?>/lib/slick/slick-theme.css" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <?php if(App::getLocale() == 'ar'): ?>
    <link href="<?php echo e(asset('assets/frontend/lib/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/frontend/lib/animate/animate.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/frontend/css/styleAr.css')); ?>" rel="stylesheet" />
    
    <?php else: ?>

    <link href="<?php echo e(asset('assets/frontend/lib/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/frontend/lib/animate/animate.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" rel="stylesheet" />
    <?php endif; ?>
    <link href="<?php echo e(asset('assets/vendor/file-input/css/fileinput.min.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('assets/vendor/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
 <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo $__env->yieldPushContent('header'); ?>
  </head>

  <body>

    <?php echo $__env->make('layouts.fronend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Breadcrumb Start -->
        <div class="breadcrumb-wrap">
            <div class="container-fluid">
              <ul class="breadcrumb">
                <?php $__env->startSection('breadcrumb'); ?>
                
                <?php echo $__env->yieldSection(); ?>

              </ul>
            </div>
          </div>
          <!-- Breadcrumb End -->

    <?php echo $__env->yieldContent('body'); ?>

    <?php echo $__env->make('layouts.fronend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php if(auth()->guard()->check()): ?>
    <script>
        role           = "user";
        userId         = "<?php echo e(auth()->user()->id); ?>";
        showPostRoute  = "<?php echo e(route('frontend.post.show' , ':slug')); ?>";
    </script>
   <?php endif; ?>
   <script src="<?php echo e(asset('build/assets/app-C1VMDXJK.js')); ?>"></script>
   <!-- Back to Top -->
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/frontend')); ?>/lib/easing/easing.min.js"></script>
    <script src="<?php echo e(asset('assets/frontend')); ?>/lib/slick/slick.min.js"></script>


    
    <!-- Template Javascript -->
    <script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/vendor/file-input/js/fileinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/file-input/themes/fa5/theme.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/vendor/summernote/summernote-bs4.min.js')); ?>"></script>


    <?php echo $__env->yieldPushContent('js'); ?>

  </body>
</html>
<?php /**PATH E:\Pro-Backend\الشغل\NKM-site\resources\views/layouts/fronend/app.blade.php ENDPATH**/ ?>