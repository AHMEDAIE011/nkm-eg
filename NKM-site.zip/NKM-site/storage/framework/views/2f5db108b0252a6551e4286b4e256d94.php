<?php $__env->startSection('title'); ?>
    Create contact
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
   <center>
        <div class="card-body shadow mb-4 col-9">
            <h4>Contact : <?php echo e($contact->name); ?></h2><br>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <input disabled value="Name : <?php echo e($contact->name); ?>" class="form-control">

                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <input disabled value=" Title : <?php echo e($contact->title); ?>" class="form-control">

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <input disabled value="Email : <?php echo e($contact->email); ?>" class="form-control">

                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <input disabled value="Phone : <?php echo e($contact->phone); ?>" class="form-control">

                    </div>
                </div>
            </div>
           
           
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                       <p><?php echo e($contact->body); ?>"</p>
                    </div>
                </div>
              
            </div>

           <br>
            
            <a href="mailto:<?php echo e($contact->email); ?>?subject=Re:<?php echo e(urlencode($contact->title)); ?>" class="btn btn-primary">Reply <i class="fa fa-reply"></i></a>
            <a href="javascript:void(0)"  onclick="if(confirm('Do you want to delete the contact')){document.getElementById('delete_contact').submit()} return false" class="btn btn-info">Delete <i class="fa fa-trash"></i></a>
        </div>

        <form id="delete_contact" action="<?php echo e(route('admin.contacts.destroy' , $contact->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
         </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/admin/contacts/show.blade.php ENDPATH**/ ?>