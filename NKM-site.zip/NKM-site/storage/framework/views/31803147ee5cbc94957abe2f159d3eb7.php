<?php $__env->startSection('title'); ?>
    Notification
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
       
       <div class="d-flex justify-content-center">

        <!-- Main Content -->
        <div class="card-body shadow mb-4" style="max-width: 100ch">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <h2 class="mb-4">Notifications</h2>
                    </div>
                    <div class="col-6">
                       <a href="<?php echo e(route('admin.notifications.deleteAll')); ?>" class="btn btn-danger" style="margin-left: 33ch">Delete All</a>
                    </div>

                </div>
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="notification alert alert-info">
                    <strong><img src="" width="50px" class="img-thumbnial rounded"> <a style="text-decoration: none" href="<?php echo e($notify->data['link']); ?>?notify_admin=<?php echo e($notify->id); ?>"><?php echo e($notify->data['user_name']); ?></a> : </strong> <?php echo e($notify->data['contact_title']); ?>.<br>
                    <strong style="color: red"> <?php echo e($notify->created_at->diffForHumans()); ?></strong>
                    <div class="float-right">
                        <a href="<?php echo e(route('admin.notifications.destroy' , $notify->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <div class="alert alert-info">
                        No Comments yet!
                    </div>
                <?php endif; ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>