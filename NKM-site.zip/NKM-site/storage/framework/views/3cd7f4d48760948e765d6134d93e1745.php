<?php $__env->startSection('title'); ?>
    Category <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('header'); ?>
<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
    <li class="breadcrumb-item active"><?php echo e($category->name); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<br><br><br>
     <!-- Main News Start-->
     <div class="main-news">
        <div class="container">
          <div class="row">
            <div class="col-lg-9">
              <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <div class="mn-img">
                        <img src="<?php echo e(asset( $post->images->first()->path)); ?>" />
                        <div class="mn-title">
                            <a href="<?php echo e(route('frontend.post.show',$post->slug)); ?>" title="<?php echo e($post->title); ?>"><?php echo e($post->title); ?></a>
                        </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <div class="col-lg-12 alert-info">
                    Category is empty
                  </div>
                <?php endif; ?>



              </div>
              <?php echo e($posts->links()); ?>

            </div>

            <div class="col-lg-3">
              <div class="mn-list">
                <h2>Other Categories</h2>
                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('frontend.category.posts' , $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Main News End-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/frontend/category-posts.blade.php ENDPATH**/ ?>