<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>