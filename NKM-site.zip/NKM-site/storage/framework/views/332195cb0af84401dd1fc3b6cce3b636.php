<?php $__env->startSection('title'); ?>
    Contact-Us
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <!-- Contact Start -->
    <div class="contact">
        <div class="container">
            <h1>Contact Us</h1><br>
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="contact-form">
                        <form action="<?php echo e(route('frontend.conact.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <input name="name" type="text" class="form-control" placeholder="Your Name" />
                                    <strong class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></strong>
                                </div>
                                <div class="form-group col-md-4">
                                    <input name="email" type="email" class="form-control" placeholder="Your Email" />
                                    <strong class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></strong>
                                </div>


                                <div class="form-group col-md-4">
                                    <input name="phone" type="text" class="form-control" placeholder="Your phone" />
                                </div>
                                <strong class="text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></strong>
                            </div>
                            <div class="form-group">
                                <input name="title" type="text" class="form-control" placeholder="Subject" />
                            </div>
                            <div class="form-group">
                                <textarea name="body" class="form-control" rows="5" placeholder="Message"></textarea>
                            </div>
                            <div>
                                <button class="btn" type="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="contact-info">
                        <h3>Get in Touch</h3>
                        <p class="mb-4">
                            The contact form is currently inactive. Get a functional and
                            working contact form with Ajax & PHP in a few minutes. Just copy
                            and paste the files, add a little code and you're done.

                        </p>
                        <h4><i class="fa fa-map-marker"></i><?php echo e($getSetting->street); ?>,<?php echo e($getSetting->city); ?> ,
                            <?php echo e($getSetting->country); ?></h4>
                        <h4><i class="fa fa-envelope"></i><?php echo e($getSetting->email); ?></h4>
                        <h4><i class="fa fa-phone"></i>+<?php echo e($getSetting->phone); ?></h4>
                        <div class="social">
                            <a href="<?php echo e($getSetting->twitter); ?>"><i class="fab fa-twitter"></i></a>
                            <a href="<?php echo e($getSetting->facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                            <a href="<?php echo e($getSetting->instagram); ?>"><i class="fab fa-instagram"></i></a>
                            <a href="<?php echo e($getSetting->youtupe); ?>"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/frontend/contact.blade.php ENDPATH**/ ?>