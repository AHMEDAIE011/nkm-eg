  <!-- Sidebar -->
  <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
          <div class="sidebar-brand-icon rotate-n-15">
              <i class="fas fa-laugh-wink"></i>
          </div>
          <div class="sidebar-brand-text mx-3"><?php echo e(config('app.name')); ?><sup></sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('home')): ?>
          <li class="nav-item active">
              <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">
                  <i class="fas fa-fw fa-tachometer-alt"></i>
                  <span>Dashboard</span></a>
          </li>
      <?php endif; ?>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
          Interface
      </div>
      <!-- Nav Item - Admin managments -->
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins')): ?>
          <li class="nav-item">
              <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#adminManagment"
                  aria-expanded="true" aria-controls="adminManagment">
                  <i class="fas fa-user fa-user"></i>
                  <span>Admins</span>
              </a>
              <div id="adminManagment" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                  <div class="bg-white py-2 collapse-inner rounded">
                      <h6 class="collapse-header">Admins managment:</h6>
                      <a class="collapse-item" href="<?php echo e(route('admin.admins.index')); ?>">Admins</a>
                      <a class="collapse-item" href="<?php echo e(route('admin.admins.create')); ?>">Add New Admin</a>
                  </div>
              </div>
          </li>
      <?php endif; ?>

         <!-- Nav Item -Authorization -->
         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('authorizations')): ?>
         <li class="nav-item">
             <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#authorizationManagent"
                 aria-expanded="true" aria-controls="authorizationManagent">
                 <i class="fas fa-fw fa-wrench"></i>
                 <span>Authorization</span>
             </a>
             <div id="authorizationManagent" class="collapse" aria-labelledby="headingUtilities"
                 data-parent="#accordionSidebar">
                 <div class="bg-white py-2 collapse-inner rounded">
                     <h6 class="collapse-header">Authorization managment:</h6>
                     <a class="collapse-item" href="<?php echo e(route('admin.authorizations.index')); ?>">Roles</a>
                     <a class="collapse-item" href="<?php echo e(route('admin.authorizations.create')); ?>"> Create Role</a>
                 </div>
             </div>
         </li>
     <?php endif; ?>
       <!-- Nav Item - Pages Collapse Menu -->
       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users')): ?>
       <li class="nav-item">
           <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
               aria-expanded="true" aria-controls="collapsePages">
               <i class="fas fa-fw fa-users"></i>
               <span>User Management</span>
           </a>
           <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
               <div class="bg-white py-2 collapse-inner rounded">
                   <a class="collapse-item" href="<?php echo e(route('admin.users.index')); ?>">Users</a>
                   <a class="collapse-item" href="<?php echo e(route('admin.users.create')); ?>">Add User</a>
               </div>
           </div>
       </li>
   <?php endif; ?>
   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories')): ?>
   <li class="nav-item">
       <a class="nav-link" href="<?php echo e(route('admin.categories.index')); ?>">
           <i class="fas fa-fw fa-table"></i>
           <span>Categories</span></a>
   </li>
<?php endif; ?>

      <!-- Nav Item - Pages Collapse Menu -->
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts')): ?>
          <li class="nav-item">
              <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                  aria-expanded="true" aria-controls="collapseTwo">
                  <i class="fas fa-folder fa-cog"></i>
                  <span>Post Managment</span>
              </a>
              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                  <div class="bg-white py-2 collapse-inner rounded">
                      <h6 class="collapse-header">posts managment:</h6>
                      <a class="collapse-item" href="<?php echo e(route('admin.posts.index')); ?>">Posts</a>
                      <a class="collapse-item" href="<?php echo e(route('admin.posts.create')); ?>">Create Post</a>
                  </div>
              </div>
          </li>
      <?php endif; ?>
      <!-- Nav Item - Utilities Collapse Menu -->






      <!-- Divider -->
      <hr class="sidebar-divider">


      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings')): ?>
      <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
              aria-expanded="true" aria-controls="collapseUtilities">
              <i class="fas fa-fw fa-wrench"></i>
              <span>Setting</span>
          </a>
          <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
              data-parent="#accordionSidebar">
              <div class="bg-white py-2 collapse-inner rounded">
                  <h6 class="collapse-header">setting managment:</h6>
                  <a class="collapse-item" href="<?php echo e(route('admin.settings.index')); ?>">Setting</a>
                  <a class="collapse-item" href="<?php echo e(route('admin.related-site.index')); ?>">Related Sites</a>
              </div>
          </div>
      </li>
  <?php endif; ?>


      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contacts')): ?>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.contacts.index')); ?>">
              <i class="fas fa-fw fa-phone"></i>
              <span>Contacts</span></a>
      </li>
      <?php endif; ?>
      

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
          <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>



  </ul>
  <!-- End of Sidebar -->
<?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/layouts/dashboard/sidebar.blade.php ENDPATH**/ ?>