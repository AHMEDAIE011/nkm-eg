<?php $__env->startSection('title'); ?>
All Categories 
<?php $__env->stopSection(); ?>
<?php $__env->startPush('header'); ?>
<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="imageCategory">
    <img src="<?php echo e(asset('assets/frontend/img/hidder.webp')); ?>" class="img-fluid" alt="">
</div>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
    <li class="breadcrumb-item active">All Categories</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<br><br><br>


   <!-- Main News Start-->
   <div class="main-news">
    <div class="container-fluid">
        <h2 class="text-center mb-4"><?php echo e(__('home.allCategory')); ?></h2>
        <div class="row">
            <div class="col-lg-9">
        <!-- عرض الفئات -->
                <div class="category-container">
                    <?php $__currentLoopData = $categories_with_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="category mb-5">
                            <h3 class="category-title"><?php echo e($category->name); ?></h3>
                            <div class="row">
                                <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 d-flex justify-content-center">
                                        <div class="mn-img card product-card  <?php if($index < 8): ?> visible <?php endif; ?>">
                                            <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>">
                                                
                                                <img  src="<?php echo e(asset($post->images->first()->path ?? '')); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>"></a>
                                            <div class="mn-title card-body text-center">
                                                <?php if(App::getLocale() == 'ar'): ?>
                                                <a class="card-title" href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title_ar); ?></a>
                                                <?php else: ?>
                                                <a class="card-title" href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                                <?php endif; ?>  
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="text-center mt-3">
                                <button class="btn btn-primary btn-more"><?php echo e(__('home.showMore')); ?></button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>  
            </div>
            <div class="col-lg-3">
                <div class="mn-list">
                <h2>Other Categories</h2>
                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(App::getLocale() == 'ar'): ?>
                    <li><a href="<?php echo e(route('frontend.category.posts' , $category->slug)); ?>"><?php echo e($category->name_ar); ?></a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(route('frontend.category.posts' , $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endif; ?>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                </div>
            </div>
     </div>
    </div>
  </div>

  <!-- Main News End-->
<script>
    document.querySelectorAll('.btn-more').forEach(button => {
        button.addEventListener('click', function () {
            let category = this.closest('.category'); // تحديد الفئة المرتبطة بالزر
            let hiddenProducts = category.querySelectorAll('.product-card:not(.visible)');

            let count = 0;
            hiddenProducts.forEach(product => {
                if (count < 4) { // إظهار 4 منتجات فقط
                    product.classList.add('visible');
                    count++;
                }
            });

            // إخفاء الزر إذا لم يعد هناك منتجات مخفية
            if (category.querySelectorAll('.product-card:not(.visible)').length === 0) {
                this.style.display = 'none';
            }
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/frontend/category-all-posts.blade.php ENDPATH**/ ?>