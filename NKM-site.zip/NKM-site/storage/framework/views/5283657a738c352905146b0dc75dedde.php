<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_desc'); ?>
    <?php echo e($getSetting->small_desc); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('header'); ?>
<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<?php
    $latest_three_posts = $posts->take(3);
?>
    <!-- Top News Start-->
    <div class="top-news">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 tn-left">
                    <div class="row tn-slider">
                       <?php $__currentLoopData = $latest_three_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-md-6">
                        <div class="tn-img">
                            <img style="height: 383px;width:540px" src="<?php echo e($post->images->first()->path); ?>" />
                            <div class="tn-title">
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                            </div>
                        </div>
                    </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-6 tn-right">
                    <?php
                        $four_posts = $posts->take(4);
                    ?>
                    <div class="row">
                        <?php $__currentLoopData = $four_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="tn-img">
                                <img style="height: 195px;width:280px" src="<?php echo e($post->images->first()->path); ?>" />
                                <div class="tn-title">
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top News End-->

    <!-- Category News Start-->
    <div class="cat-news">
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $categories_with_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <h2><?php echo e($category->name); ?></h2>
                    <div class="row cn-slider">
                       <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="cn-img">
                                <img src="<?php echo e($post->images->first()->path ?? ''); ?>" />
                                <div class="cn-title">
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                </div>
                            </div>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Category News End-->



    <!-- Tab News Start (finished)-->
    <div class="tab-news">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <ul class="nav nav-pills nav-justified">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#featured"> Popular News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#popular"> Oldest News</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="featured" class="container tab-pane active">
                           <?php $__currentLoopData = $gretest_posts_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tn-news">
                                <div class="tn-img">
                                    <img src="<?php echo e(asset( $post->images->first()->path )); ?>" />
                                </div>
                                <div class="tn-title">
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?> comment(<?php echo e($post->comments_count); ?>)</a>
                                </div>
                            </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div id="popular" class="container tab-pane fade">
                            <?php $__currentLoopData = $oldest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tn-news">
                                <div class="tn-img">
                                    <img src="<?php echo e($post->images->first()->path ?? ''); ?>" />
                                </div>
                                <div class="tn-title">
                                    <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>

                <div class="col-md-6">
                    <ul class="nav nav-pills nav-justified">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#m-viewed">Latest News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#m-read">Most Read</a>
                        </li>

                    </ul>

                    <div class="tab-content">
                        
                        <div id="m-viewed" class="container tab-pane active">
                           <?php $__currentLoopData = $latest_three_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="tn-news">
                            <div class="tn-img">
                                <img src="<?php echo e($post->images->first()->path ?? ''); ?>" />
                            </div>
                            <div class="tn-title">
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                            </div>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div id="m-read" class="container tab-pane fade">
                          <?php $__currentLoopData = $gretest_posts_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="tn-news">
                            <div class="tn-img">
                                <img src="<?php echo e($post->images->first()->path ?? ''); ?>" />
                            </div>
                            <div class="tn-title">
                                <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?> (<?php echo e($post->num_of_views); ?>)</a>
                            </div>
                        </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Tab News Start-->

    <!-- Main News Start-->
    <div class="main-news">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-9">
                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="mn-img">
                                  <img style="height: 150px;width:260px" src="<?php echo e($post->images->first()->path ?? ''); ?>" />
                                    <div class="mn-title">
                                        <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($posts->links()); ?>

                    </div>
                </div>

                <div class="col-lg-3">
                    <div class="mn-list">
                        <h2>Read More</h2>
                        <ul>
                          <?php $__currentLoopData = $read_more_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main News End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/frontend/index.blade.php ENDPATH**/ ?>