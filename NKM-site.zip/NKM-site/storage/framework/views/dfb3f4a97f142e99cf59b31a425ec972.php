<?php echo e($slot); ?>

<?php /**PATH E:\New folder\project-hossam\NKM-site\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>