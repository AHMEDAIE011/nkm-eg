<?php $__env->startSection('title'); ?>
    Search News
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
     <!-- Main News Start-->
     <div class="main-news">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="mn-img">
                                  <img src="<?php echo e($post->images->first()->path); ?>" />
                                    <div class="mn-title">
                                        <a href="<?php echo e(route('frontend.post.show' , $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <?php echo e($posts->links()); ?>



            </div>
        </div>
    </div>
    <!-- Main News End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/frontend/search.blade.php ENDPATH**/ ?>