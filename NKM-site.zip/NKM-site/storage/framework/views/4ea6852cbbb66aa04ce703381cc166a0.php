<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tables</h1>
    <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
        For more information about DataTables, please visit the <a target="_blank"
            href="https://datatables.net">official DataTables documentation</a>.</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
        </div>

        <?php echo $__env->make('admin.users.filter.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Country</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Country</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td> <?php echo e($user->name); ?></td>
                        <td> <?php echo e($user->email); ?></td>
                        <td><?php echo e($user->status==1?'Active':'Not Active'); ?></td>
                        <td><?php echo e($user->country); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <td>
                            <a href="javascript:void(0)" onclick="if(confirm('Do you want to delete the user')){document.getElementById('delete_user_<?php echo e($user->id); ?>').submit()} return false"><i class="fa fa-trash"></i></a>
                            <a href="<?php echo e(route('admin.users.changeStatus', $user->id)); ?>"><i class="fa <?php if($user->status==1): ?>fa-stop <?php else: ?> fa-play <?php endif; ?>"></i></a>
                            <a href="<?php echo e(route('admin.users.show' , $user->id)); ?>" ><i class="fa fa-eye"></i></a>
                        </td>
                     </tr>

                     <form id="delete_user_<?php echo e($user->id); ?>" action="<?php echo e(route('admin.users.destroy' , $user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                     </form>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <tr>
                            <tdv class="alert alert-info" colspan="6"> No Users</td>
                         </tr>
                     <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($users->appends(request()->input())->links()); ?>

            </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/admin/users/index.blade.php ENDPATH**/ ?>