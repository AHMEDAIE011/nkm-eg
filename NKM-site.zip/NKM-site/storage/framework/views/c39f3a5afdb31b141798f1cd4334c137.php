<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>

    </div>

    <!-- Content Row -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.statistics');

$__html = app('livewire')->mount($__name, $__params, 'lw-145057784-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <!-- Content Row -->
    
    <div class="row">

        <div class="card-body shadow col-6">
            <h4><?php echo e($posts_chart->options['chart_title']); ?></h4>
            <?php echo $posts_chart->renderHtml(); ?>


        </div>
        <div class="card-body shadow col-6">
            <h4> <?php echo e($users_chart->options['chart_title']); ?> </h4>
            <?php echo $users_chart->renderHtml(); ?>


        </div>
    </div>

    <!--Posts && Comments Row -->
    <<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.latest-posts-comments');

$__html = app('livewire')->mount($__name, $__params, 'lw-145057784-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>)

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $posts_chart->renderChartJsLibrary(); ?>


<?php echo $posts_chart->renderJs(); ?>

<?php echo $users_chart->renderJs(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/admin/index.blade.php ENDPATH**/ ?>