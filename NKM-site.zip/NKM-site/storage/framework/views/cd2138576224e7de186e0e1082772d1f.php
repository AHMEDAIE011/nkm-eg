<?php $__env->startSection('title'); ?>
    Create Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="d-flex justify-content-center">
        <form action="<?php echo e(route('admin.authorizations.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body shadow mb-4" style="max-width: 90ch">
            <div class="row">
                <div class="col-9">
                    <h2>Add New Role</h2>
                </div>
                <div class="col-3">
                    <a href="<?php echo e(route('admin.authorizations.index')); ?>" class="btn btn-primary">Back To Roles</a>
                </div>
            </div><br>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <input type="text" name="role" placeholder="Enter Role Name" class="form-control">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <?php $__currentLoopData = config('authorization.permessions'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-4">
                        <div class="form-group">
                                <?php echo e($value); ?> : <input value="<?php echo e($key); ?>" type="checkbox" name="permessions[]">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

               <button type="submit" class="btn btn-primary">Create New Role</button>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/admin/authorizations/create.blade.php ENDPATH**/ ?>