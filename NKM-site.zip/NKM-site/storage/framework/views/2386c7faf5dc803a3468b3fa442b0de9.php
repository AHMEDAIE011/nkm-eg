<?php $__env->startSection('title'); ?>
    Create User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="d-flex justify-content-center">
        <div class="card-body shadow mb-4" style="max-width: 100ch">
            <a class="btn btn-primary" href="<?php echo e(route('admin.posts.index', ['page' => request()->page])); ?>">Back To Posts</a>
            <br><br>
            <div id="newsCarousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#newsCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#newsCarousel" data-slide-to="1"></li>
                    <li data-target="#newsCarousel" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" style="height: 70ch">
                    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php if($index == 0): ?> active <?php endif; ?>">
                            <img src="<?php echo e(asset($image->path)); ?>" class="d-block w-100" alt="First Slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h5><?php echo e($post->title); ?></h5>
                                <p>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Add more carousel-item blocks for additional slides -->
                </div>
                <a class="carousel-control-prev" href="#newsCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#newsCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <br>
            <div class="row">
                <div class="col-4">
                    <h6>
                        Publisher : <?php echo e($post->user->name ?? $post->admin->name); ?> <i class="fa fa-user"></i>
                    </h6>
                </div>
                <div class="col-4">
                    <h6>
                        Views : <?php echo e($post->num_of_views); ?> <i class="fa fa-eye"></i>
                    </h6>
                </div>
                <div class="col-4">
                    <h6>
                        Created At : <?php echo e($post->created_at->format('Y-m-d h:m')); ?> <i class="fa fa-edit"></i>
                    </h6>
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <h6>
                        Comments : <?php echo e($post->comment_able == 1 ? 'Active' : 'Not Active'); ?> <i class="fa fa-comment"></i>
                    </h6>
                </div>
                <div class="col-4">
                    <h6>
                        Status : <?php echo e($post->status == 1 ? 'Active' : 'Not Active'); ?> <i
                            class="fa <?php if($post->status == 0): ?> fa-plane <?php else: ?> fa-wifi <?php endif; ?> "></i>
                    </h6>
                </div>
                <div class="col-4">
                    <h6>
                        Category : <?php echo e($post->category->name); ?> <i class="fa fa-folder"></i>
                    </h6>
                </div>
            </div>
            <br>
            <div class="sn-content">
                <strong>Small Description : <?php echo e($post->small_desc); ?></strong>
            </div>
            <br>
            <div class="sn-content">
                <?php echo $post->desc; ?>

            </div>

            <br>
            <center>
                <a class="btn btn-danger" href="javascript:void(0)"
                    onclick="if(confirm('Do you want to delete the post')){document.getElementById('delete_post_<?php echo e($post->id); ?>').submit()} return false">Delete
                    Post <i class="fa fa-trash"></i></a>
                <a class="btn btn-primary" href="<?php echo e(route('admin.posts.changeStatus', $post->id)); ?>">Change Status <i
                        class="fa <?php if($post->status == 1): ?> fa-stop <?php else: ?> fa-play <?php endif; ?>"></i></a>
                <a class="btn btn-info" href="<?php echo e(route('admin.posts.edit', $post->id)); ?>">Edit Post <i
                        class="fa fa-edit"></i></a>
            </center>
        </div>
    </div>
    <form id="delete_post_<?php echo e($post->id); ?>" action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>



    
    <div class="d-flex justify-content-center">

        <!-- Main Content -->
        <div class="card-body shadow mb-4" style="max-width: 100ch">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <h2 class="mb-4">Comments</h2>
                    </div>

                </div>
                <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="notification alert alert-info">
                    <strong><img src="<?php echo e(asset($comment->user->image)); ?>" width="50px" class="img-thumbnial rounded"> <a style="text-decoration: none" href="<?php echo e(route('admin.users.show' , $comment->user->id)); ?>"><?php echo e($comment->user->name); ?></a> : </strong> <?php echo e($comment->comment); ?>.<br>
                    <strong style="color: red"> <?php echo e($comment->created_at->diffForHumans()); ?></strong>
                    <div class="float-right">
                        <a href="<?php echo e(route('admin.posts.deleteComment' , $comment->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <div class="alert alert-info">
                        No Comments yet!
                    </div>
                <?php endif; ?>







            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>