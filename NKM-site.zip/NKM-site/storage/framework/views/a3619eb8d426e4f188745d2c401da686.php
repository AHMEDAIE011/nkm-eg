  <!-- Top Bar Start -->
  <div class="top-bar">
      <div class="container">
          <div class="row">
              <div class="col-md-6">
                  <div class="tb-contact">
                      <p><i class="fas fa-envelope"></i> <?php echo e($getSetting->email); ?></p>
                      <p><i class="fas fa-phone-alt"></i> <?php echo e($getSetting->phone); ?></p>
                  </div>
              </div>
              <div class="col-md-6">
                  <div class="tb-menu text-right">
                      <?php if(auth()->guard()->guest()): ?>
                          <a href="<?php echo e(route('register')); ?>">Register</a>
                          <a href="<?php echo e(route('login')); ?>">Login</a>
                      <?php endif; ?>
                      <?php if(auth()->guard()->check()): ?>
                          <a href="javascript:void(0)"
                              onclick="if(confirm('Do you want to logout')){document.getElementById('formLogout').submit()} return false">Logout</a>
                          <form id="formLogout" action="<?php echo e(route('logout')); ?>" method="post" style="display: none;">
                              <?php echo csrf_field(); ?>
                          </form>
                      <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- Top Bar End -->

  <!-- Brand Start -->
  <div class="brand">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-lg-3 col-md-4">
                  <div class="b-logo">
                      <a href="index.html">
                          <img src="<?php echo e(asset($getSetting->logo)); ?>" alt="Logo" />
                      </a>
                  </div>
              </div>
              <div class="col-lg-6 col-md-4">
                <div class="b-ads">
                  <a href="https://htmlcodex.com">
                    <img style="" src="<?php echo e(asset('assets/frontend')); ?>/img/hidder-pro.webp" alt="Ads" />
                  </a>
                </div>
              </div>
              <div class="col-lg-3 col-md-4">
                  <form action="<?php echo e(route('frontend.search')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <div class="b-search">
                          <input name="search" type="text" placeholder="Search" />
                          <button type="submit"><i class="fa fa-search"></i></button>
                      </div>
                  </form>
              </div>
          </div>
      </div>
  </div>
  <!-- Brand End -->

  <!-- Nav Bar Start -->
  <div class="nav-bar">
      <div class="container">
          <nav class="navbar navbar-expand-md bg-dark navbar-dark">
              <a href="#" class="navbar-brand">MENU</a>
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                  <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                  <div class="navbar-nav mr-auto">
                      <a href="<?php echo e(route('frontend.index')); ?>" class="nav-item nav-link "><?php echo e(__('home.home')); ?></a>
                      <div class="nav-item dropdown">
                          <a href="<?php echo e(route('frontend.categories.posts')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo e(__('home.products')); ?></a>
                          <div class="dropdown-menu">
                            <a href="<?php echo e(route('frontend.categories.posts')); ?>"
                                class="dropdown-item" title="All Category"><?php echo e(__('home.allCategory')); ?></a>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if(App::getLocale() == 'ar'): ?>
                              <a href="<?php echo e(route('frontend.category.posts', $category->slug)); ?>"
                                class="dropdown-item" title="<?php echo e($category->name); ?>"><?php echo e($category->name_ar); ?></a>
                              <?php else: ?>
                              <a href="<?php echo e(route('frontend.category.posts', $category->slug)); ?>"
                                  class="dropdown-item" title="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></a>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                      </div>
                      


                      <a href="<?php echo e(route('frontend.conact.index')); ?>" class="nav-item nav-link"><?php echo e(__('home.ContactUs')); ?></a>
                      <a href="<?php echo e(route('frontend.conact.index')); ?>" class="nav-item nav-link"> <?php echo e(__('home.about')); ?></a>
                      <a href="<?php echo e(route('frontend.dashboard.profile')); ?>" class="nav-item nav-link"><?php echo e(__('home.account')); ?></a>
                      <div class="nav-item dropdown">
                        <a href="<?php echo e(route('frontend.categories.posts')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo e(App::getLocale()); ?></a>
                        <div class="dropdown-menu">
                              <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                        <?php echo e($properties['native']); ?>

                                    </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                  </div>

                  <!-- Social Links and Notification Dropdown -->
                  <div class="social ml-auto">
                      <!-- Notification Dropdown -->
                      <?php if(auth()->guard('web')->check()): ?>
                        <a href="#" class="nav-link dropdown-toggle" id="notificationDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span id="count-notification" class="badge badge-danger"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notificationDropdown"
                        style="width: 300px;">
                        <h5>Notifications</h5>
                        
                        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div id="push-notification">
                                <div class="dropdown-item d-flex justify-content-between align-items-center">
                                    <span> Post Comment : <?php echo e(substr($notify->data['post_title'], 0, 9)); ?>...</span>
                                    <a href="<?php echo e(route('frontend.post.show', $notify->data['post_slug'])); ?>?notify=<?php echo e($notify->id); ?>"><i
                                            class="fa fa-eye"></i></a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <div class="dropdown-item text-center">No notifications</div>
                        <?php endif; ?>


                    </div>
                      <?php endif; ?>
                      <a href="<?php echo e($getSetting->twitter); ?>" title="twitter"><i class="fab fa-twitter" rel="nofollow"></i></a>
                      <a href="<?php echo e($getSetting->facebook); ?>" title="facebook"><i class="fab fa-facebook-f" rel="nofollow"></i></a>
                      <a href="<?php echo e($getSetting->instagram); ?>" title="instagram"><i class="fab fa-instagram" rel="nofollow"></i></a>
                      <a href="<?php echo e($getSetting->youtupe); ?>" title="youtube"><i class="fab fa-youtube" rel="nofollow"></i></a>


                  </div>
              </div>
          </nav>
      </div>
  </div>
  <!-- Nav Bar End -->
<?php /**PATH E:\Pro-Backend\الشغل\NKM-site\resources\views/layouts/fronend/header.blade.php ENDPATH**/ ?>