<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Admin Managment</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Admin Managment</h6>
        </div>

        <?php echo $__env->make('admin.admins.filter.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Role</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Role</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($admin->name); ?></td>
                        <td><?php echo e($admin->username); ?></td>
                        <td><?php echo e($admin->email); ?></td>
                        <td><?php echo e($admin->status==1? 'Active' : 'Not Active'); ?></td>
                        <td><?php echo e($admin->authorization->role); ?></td>
                        <td><?php echo e($admin->created_at->format('Y-m-d h:m a')); ?></td>
                        <td>
                            <a href="javascript:void(0)" onclick="if(confirm('Do you want to delete the admin')){document.getElementById('delete_admin_<?php echo e($admin->id); ?>').submit()} return false"><i class="fa fa-trash"></i></a>
                            <a href="<?php echo e(route('admin.admins.changeStatus', $admin->id)); ?>"><i class="fa <?php if($admin->status==1): ?>fa-stop <?php else: ?> fa-play <?php endif; ?>"></i></a>
                            <a href="<?php echo e(route('admin.admins.edit' , $admin->id)); ?>" ><i class="fa fa-edit"></i></a>
                        </td>
                     </tr>

                     <form id="delete_admin_<?php echo e($admin->id); ?>" action="<?php echo e(route('admin.admins.destroy' , $admin->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                     </form>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <tr>
                            <td class="alert alert-info" colspan="8"> No admins</td>
                         </tr>
                     <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($admins->appends(request()->input())->links()); ?>

            </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/admin/admins/index.blade.php ENDPATH**/ ?>