<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Roles Managment</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Roles Managment</h6>
        </div>
        <br>
        <div class="col-3">
            <a href="<?php echo e(route('admin.authorizations.create')); ?>" class="btn btn-info">Create New Role </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Role Name</th>
                            <th>Permessions</th>
                            <th>Related Admins</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Role Name</th>
                            <th>Permessions</th>
                            <th>Related Admins</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $authorizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $authorization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($authorization->role); ?></td>
                        <td>
                            <?php $__currentLoopData = $authorization->permessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php echo e($permession); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($authorization->admins->count()); ?></td>
                        <td><?php echo e($authorization->created_at->format('Y-m-d h:m a')); ?></td>
                        <td>
                            <a href="javascript:void(0)" onclick="if(confirm('Do you want to delete this Role')){document.getElementById('delete_role_<?php echo e($authorization->id); ?>').submit()} return false"><i class="fa fa-trash"></i></a>
                            <a href="<?php echo e(route('admin.authorizations.edit' , $authorization->id)); ?>" ><i class="fa fa-edit"></i></a>
                        </td>
                     </tr>

                     <form id="delete_role_<?php echo e($authorization->id); ?>" action="<?php echo e(route('admin.authorizations.destroy' , $authorization->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                     </form>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <tr>
                            <td class="alert alert-info" colspan="5"> No authorizations</td>
                         </tr>
                     <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($authorizations->appends(request()->input())->links()); ?>

            </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/admin/authorizations/index.blade.php ENDPATH**/ ?>