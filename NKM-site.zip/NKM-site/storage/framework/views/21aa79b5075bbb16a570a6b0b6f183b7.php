<?php $__env->startSection('title'); ?>
    Show <?php echo e($mainPost->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('header'); ?>
<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('meta_desc'); ?>
     <?php echo e($mainPost->small_desc); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="imageCategory">
    <img src="<?php echo e(asset('assets/frontend/img/hidder-pro.webp')); ?>" class="img-fluid" alt="">
</div>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="breadcrumb-item "><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
    <li class="breadcrumb-item active"><?php echo e($mainPost->title); ?></li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('body'); ?>
    <!-- Single News Start-->
    <div class="single-news">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <!-- Carousel -->
                    <div id="newsCarousel" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#newsCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#newsCarousel" data-slide-to="1"></li>
                            <li data-target="#newsCarousel" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $mainPost->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php if($index == 0 ): ?> active <?php endif; ?>">
                                    <img style="height: 800px;" src="<?php echo e(asset($image->path)); ?>" class="d-block w-100" alt="First Slide">
                                    <div class="carousel-caption d-none d-md-block">
                                        <h5><?php echo e($mainPost->title); ?></h5>
                                        <p>

                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Add more carousel-item blocks for additional slides -->
                        </div>
                        <a class="carousel-control-prev" href="#newsCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#newsCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                    <div class="alert alert-info">
                        Sub Descrption :  <?php echo e($mainPost->small_desc); ?>

                    </div>
                    <div class="sn-content">
                        <?php echo $mainPost->desc; ?>

                    </div>

                    <?php if(auth()->guard()->check()): ?>
                         <!-- Comment Section -->
                    <?php if(auth('web')->user()->status != 0): ?>
                    <div class="comment-section">
                        <!-- Comment Input -->
                        <?php if($mainPost->comment_able == true): ?>
                            <form id="commentForm">
                                <div class="comment-input">
                                    <?php echo csrf_field(); ?>
                                    <input id="commentInput" name="comment" type="text" placeholder="Add a comment..." />
                                    <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                    <input type="hidden" name="post_id" value="<?php echo e($mainPost->id); ?>">
                                    <button type="submit">Comment</button>
                                </div>
                            </form>
                        <?php else: ?>
                          <div class="alert alert-info">
                            Unable To Comment
                          </div>
                        <?php endif; ?>
                        <div style="display: none" id="errorMsg" class="alert alert-danger">
                            
                        </div>
                        <!-- Display Comments -->
                        <div class="comments">
                            <?php $__currentLoopData = $mainPost->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="comment">
                                    <img  src="<?php echo e(asset($comment->user->image)); ?>" alt="User Image" class="comment-img" />
                                    <div class="comment-content">
                                        <span class="username"><?php echo e($comment->user->name); ?></span>
                                        <p class="comment-text"><?php echo e($comment->comment); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <!-- Add more comments here for demonstration -->
                        </div>

                        <!-- Show More Button -->
                        <?php if($mainPost->comments->count() > 2): ?>
                            <button id="showMoreBtn" class="show-more-btn">Show more</button>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>

                    <!-- Related News -->

                    <div class="sn-related">
                        <h2>Related Products</h2>
                        <div class="row sn-slider">
                            <?php $__currentLoopData = $posts_belongs_to_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="sn-img">
                                        <img style="height: 440px;width:445px" src="<?php echo e(asset(asset($post->images->first()->path))); ?>" class="img-fluid"
                                            alt="<?php echo e($post->title); ?>" />
                                        <div class="sn-title">
                                            <a
                                                href="<?php echo e(route('frontend.post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="sidebar">
                        <div class="sidebar-widget">
                            <h2 class="sw-title">In This Category</h2>
                            <div class="news-list">
                                <?php $__currentLoopData = $posts_belongs_to_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="nl-item">
                                        <div class="nl-img">
                                            <img src="<?php echo e(asset(asset($post->images->first()->path))); ?>" />
                                        </div>
                                        <div class="nl-title">
                                            <a
                                                href="<?php echo e(route('frontend.post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>

                        <div class="sidebar-widget">
                            <div class="tab-news">
                                <ul class="nav nav-pills nav-justified">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="pill" href="#featured">Latest</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="pill" href="#popular">Popular</a>
                                    </li>
                                </ul>

                                <div class="tab-content">
                                    <div id="featured" class="container tab-pane active">
                                        <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tn-news">
                                                <div class="tn-img">
                                                    <img  src="<?php echo e(asset(asset($post->images->first()->path))); ?>" />
                                                </div>
                                                <div class="tn-title">
                                                    <a
                                                        href="<?php echo e(route('frontend.post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                    
                                    <div id="popular" class="container tab-pane fade">
                                        <?php $__currentLoopData = $gretest_posts_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tn-news">
                                                <div class="tn-img">
                                                    <img src="<?php echo e(asset( $post->images->first()->path)); ?>" />
                                                </div>
                                                <div class="tn-title">
                                                    <a
                                                        href="<?php echo e(route('frontend.post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-widget">
                            <h2 class="sw-title">News Category</h2>
                            <div class="category">
                                <ul>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a
                                                href=""><?php echo e($category->name); ?></a><span>(<?php echo e($category->posts->count()); ?>)</span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                        


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Single News End-->

        <!-- Contact Start -->
        <div class="contact">
            <div class="container-fluid">
                <h1>Contact Us</h1><br>
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="contact-form">
                            <form action="<?php echo e(route('frontend.conact.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <input name="name" type="text" class="form-control" placeholder="Your Name" />
                                        <strong class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></strong>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input name="email" type="email" class="form-control" placeholder="Your Email" />
                                        <strong class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></strong>
                                    </div>
    
    
                                    <div class="form-group col-md-4">
                                        <input name="phone" type="text" class="form-control" placeholder="Your phone" />
                                    </div>
                                    <strong class="text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></strong>
                                </div>
                                <div class="form-group">
                                    <input name="title" type="hidden" class="form-control" value="<?php echo $mainPost->title; ?>" placeholder="Subject" />
                                </div>
                                <div class="form-group">
                                    <textarea name="body" class="form-control" rows="5" placeholder="Message"></textarea>
                                </div>
                                <div>
                                    <button class="btn" type="submit">Send Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-info">
                            <h3>Get in Touch</h3>
                            <p class="mb-4">
                                The contact form is currently inactive. Get a functional and
                                working contact form with Ajax & PHP in a few minutes. Just copy
                                and paste the files, add a little code and you're done.
    
                            </p>
                            <h4><i class="fa fa-map-marker"></i><?php echo e($getSetting->street); ?>,<?php echo e($getSetting->city); ?> ,
                                <?php echo e($getSetting->country); ?></h4>
                            <h4><i class="fa fa-envelope"></i><?php echo e($getSetting->email); ?></h4>
                            <h4><i class="fa fa-phone"></i>+<?php echo e($getSetting->phone); ?></h4>
                            <div class="social">
                                <a href="<?php echo e($getSetting->twitter); ?>"><i class="fab fa-twitter"></i></a>
                                <a href="<?php echo e($getSetting->facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                                <a href="<?php echo e($getSetting->instagram); ?>"><i class="fab fa-instagram"></i></a>
                                <a href="<?php echo e($getSetting->youtupe); ?>"><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

    <script>
        var baseUrl = "<?php echo e(asset('')); ?>";
        // show more comments
        $(document).on('click', '#showMoreBtn', function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('frontend.post.getAllComments', $mainPost->slug)); ?>",
                type: 'GET',
                success: function(data) {
                    $('.comments').empty();
                    $.each(data, function(key, comment) {
                        $('.comments').append(`<div class="comment">
                        <img src="${comment.user.image}" alt="User Image" class="comment-img" />
                        <div class="comment-content">
                          <span class="username">${comment.user.name}</span>
                          <p class="comment-text">${comment.comment}</p>
                        </div>
                      </div>`);
                        $('#showMoreBtn').hide();

                    });

                },
                error: function(data) {

                },
            });

        });

        // save comments
        $(document).on('submit', '#commentForm', function(e) {
            e.preventDefault();
            var formData = new FormData($(this)[0]);

            $('#commentInput').val('');

            $.ajax({
                url: "<?php echo e(route('frontend.post.comments.store')); ?>",
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,

                success: function(data) {
                    $('#errorMsg').hide();
                    $('.comments').prepend(`<div class="comment">
                                    <img src="${baseUrl}${data.comment.user.image}" alt="User Image" class="comment-img" />
                                    <div class="comment-content">
                                        <span class="username">${data.comment.user.name}</span>
                                        <p class="comment-text">${data.comment.comment}</p>
                                    </div>
                                </div>`);
                },

                error: function(data) {
                    var response = $.parseJSON(data.responseText);
                    $('#errorMsg').text(response.errors.comment).show();
                },

            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.fronend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\New folder\project-hossam\NKM-site\resources\views/frontend/show.blade.php ENDPATH**/ ?>