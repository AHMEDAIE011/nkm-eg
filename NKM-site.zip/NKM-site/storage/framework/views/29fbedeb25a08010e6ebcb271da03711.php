   <!-- Footer Start -->
   <div class="footer">
       <div class="container">
           <div class="row">
               <div class="col-lg-3 col-md-6">
                   <div class="footer-widget">
                       <h3 class="title">Get in Touch</h3>
                       <div class="contact-info">
                           <p><i class="fa fa-map-marker"></i><?php echo e($getSetting->street); ?> , <?php echo e($getSetting->city); ?> , <?php echo e($getSetting->country); ?></p>
                           <p><i class="fa fa-envelope"></i><?php echo e($getSetting->email); ?></p>
                           <p><i class="fa fa-phone"></i>+<?php echo e($getSetting->phone); ?></p>
                           <div class="social">
                               <a href="<?php echo e($getSetting->twitter); ?>" title="twitter" rel="nofollow"><i class="fab fa-twitter"></i></a>
                               <a href="<?php echo e($getSetting->facebook); ?>" title="facebook" rel="nofollow"><i
                                       class="fab fa-facebook-f"></i></a>
                               <a href="<?php echo e($getSetting->instagram); ?>" title="instagram" rel="nofollow"><i
                                       class="fab fa-instagram"></i></a>
                               <a href="<?php echo e($getSetting->youtupe); ?>" title="youtupe"><i class="fab fa-youtube" rel="nofollow"></i></a>
                           </div>
                       </div>
                   </div>
               </div>

               <div class="col-lg-3 col-md-6">
                   <div class="footer-widget">
                       <h3 class="title">Useful Links</h3>
                       <ul>
                          <?php $__currentLoopData = $relatedSites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><a href="<?php echo e($site->url); ?>" title="<?php echo e($site->name); ?>"><?php echo e($site->name); ?></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </ul>
                   </div>
               </div>

               <div class="col-lg-3 col-md-6">
                   <div class="footer-widget">
                       <h3 class="title">Quick Links</h3>
                       <ul>
                           <li><a href="#">Lorem ipsum</a></li>
                           <li><a href="#">Pellentesque</a></li>
                           <li><a href="#">Aenean vulputate</a></li>
                           <li><a href="#">Vestibulum sit amet</a></li>
                           <li><a href="#">Nam dignissim</a></li>
                       </ul>
                   </div>
               </div>

               <div class="col-lg-3 col-md-6">
                   <div class="footer-widget">
                       <h3 class="title">Newsletter</h3>
                       <div class="newsletter">
                           <p>
                               Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                               Vivamus sed porta dui. Class aptent taciti sociosqu
                           </p>
                           <form action="<?php echo e(route('frontend.news.subscrice')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                               <input class="form-control" type="email" name="email" placeholder="Your email here" />
                               <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <div class="text-danger"><?php echo e($message); ?></div>
                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               <button class="btn">Submit</button>
                           </form>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>
   <!-- Footer End -->


   <!-- Footer Bottom Start -->
   <div class="footer-bottom">
       <div class="container">
           <div class="row">
               <div class="col-md-6 copyright">
                   <p>
                       Copyright &copy; <a href=""><?php echo e(config('app.name')); ?></a>. All Rights
                       Reserved
                   </p>
               </div>

               <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
               <div class="col-md-6 template-by">
                   <p>Designed By <a href="https://htmlcodex.com">HTML Codex</a></p>
               </div>
           </div>
       </div>
   </div>
   <!-- Footer Bottom End -->
<?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\resources\views/layouts/fronend/footer.blade.php ENDPATH**/ ?>