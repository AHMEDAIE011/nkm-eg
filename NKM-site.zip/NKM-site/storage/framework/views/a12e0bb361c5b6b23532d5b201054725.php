<?php echo e($slot); ?>

<?php /**PATH E:\New folder\LARAVEL\projects-Traning\news-site\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>